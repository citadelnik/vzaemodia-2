
    function navigate(page) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.getElementById('page-' + page).classList.add('active');
    window.scrollTo({top: 0, behavior: 'instant'});
    updateNavLinks(page);
    document.getElementById('mobileMenu').classList.remove('open');
}

    function updateNavLinks(page) {
    document.querySelectorAll('[data-page]').forEach(a => {
        a.classList.toggle('active-link', a.dataset.page === page);
    });
}

    function toggleMobile() {
    const m = document.getElementById('mobileMenu');
    m.classList.toggle('open');
}

    function toggleFaq(el) {
    el.parentElement.classList.toggle('open');
}

    function handleBooking() {
    alert('Дякуємо. Ми зв\u2019яжемося з вами протягом 30 хвилин обраним вами способом.');
}

    function handleContact() {
    alert('Повідомлення отримано. Ми відповімо вам протягом 30 хвилин.');
}

    updateNavLinks('home');

    document.querySelectorAll('a[href="#"]').forEach(a => {
    a.addEventListener('click', e => e.preventDefault());
});

    document.addEventListener('click', function (e) {
        const videoBlock = e.target.closest('.video-ph');
        if (!videoBlock) return;

        const videoId = videoBlock.dataset.video;

        // если уже iframe — ничего не делаем
        if (videoBlock.querySelector('iframe')) return;

        const iframe = document.createElement('iframe');
        iframe.src = `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0&controls=1`;
        iframe.allow = "autoplay; encrypted-media";
        iframe.allowFullscreen = true;

        iframe.style.width = "100%";
        iframe.style.height = "100%";
        iframe.style.border = "0";

        videoBlock.innerHTML = "";
        videoBlock.appendChild(iframe);
    });

    const slider = document.querySelector('.slider');
    const track = slider.querySelector('.slider-track');
    const slides = slider.querySelectorAll('.slide');

    let index = 0;

    function getSlideWidth() {
        const slide = slides[0];
        const gap = 16;
        return slide.offsetWidth + gap;
    }

    function updateSlider() {
        track.style.transform = `translateX(-${index * getSlideWidth()}px)`;
    }

    slider.querySelector('.next').addEventListener('click', () => {
        if (index < slides.length - 2.5) {
            index++;
        }
        updateSlider();
    });

    slider.querySelector('.prev').addEventListener('click', () => {
        if (index > 0) {
            index--;
        }
        updateSlider();
    });

    let startX = 0;
    let currentX = 0;
    let isDragging = false;

    const sliderEl = document.querySelector('.slider');

    // TOUCH START
    sliderEl.addEventListener('touchstart', (e) => {
        startX = e.touches[0].clientX;
        isDragging = true;
    });

    // TOUCH MOVE
    sliderEl.addEventListener('touchmove', (e) => {
        if (!isDragging) return;
        currentX = e.touches[0].clientX;
    });

    // TOUCH END
    sliderEl.addEventListener('touchend', () => {
        if (!isDragging) return;

        const diff = startX - currentX;

        // 👉 чувствительность (можешь менять)
        if (diff > 50) {
            // свайп влево → next
            if (index < slides.length - 2.5) {
                index++;
                updateSlider();
            }
        } else if (diff < -50) {
            // свайп вправо → prev
            if (index > 0) {
                index--;
                updateSlider();
            }
        }

        isDragging = false;
    });

    const modal = document.getElementById('imageModal');
    const modalImg = document.getElementById('modalImg');
    const closeBtn = document.querySelector('.close-modal');

    // открытие
    document.querySelectorAll('.slide img').forEach(img => {
        img.addEventListener('click', function () {
            modal.style.display = 'flex';
            modalImg.src = this.src;
        });
    });

    // закрытие по крестику
    closeBtn.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    // закрытие по клику вне картинки
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });